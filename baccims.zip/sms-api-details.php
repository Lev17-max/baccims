<?php

	// $apicode = "TR-LEVIB619824_2YTWZ";
	// $pass = "up}]u8rk1!";
    $apicode = "TR-GENOT769954_3UL63";
    $pass = "hc(6#7%1[7";
    
    //  $apicode = "TR-KALAU293676_QQUQT";
    //  $pass = "ccrb5xrkc8";

    // $apicode =  "TR-JERON553567_JJADB";
    // $pass = "apw#unaidb";

//     ApiCode: TR-GENOT769954_3UL63
// ApiPassword: hc(6#7%1[7



	// $apicode = "TR-LEVIB619824_2YTWZ";
	// $pass = "up}]u8rk1!";
    // $apicode = "TR-GENOT769954_3UL63";
    // $pass = "hc(6#7%1[7";
    
    //  $apicode = "TR-KALAU293676_QQUQT";
    //  $pass = "ccrb5xrkc8";

    $apicode =  "TR-JERON553567_JJADB";
    $pass = "apw#unaidb";
  
//     $ApiCode: TR-GENOT769954_3UL63
// $ApiPassword: hc(6#7%1[7






  




    
?>