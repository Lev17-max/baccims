<?php

	// $apicode = "TR-LEVIB619824_2YTWZ";
	// $pass = "up}]u8rk1!";
    $apicode = "TR-GENOT769954_3UL63";
    $pass = "hc(6#7%1[7";


//     ApiCode: TR-GENOT769954_3UL63
// ApiPassword: hc(6#7%1[7

    
?>