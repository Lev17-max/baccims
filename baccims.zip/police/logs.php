<div id="logs" class="row animate__animated animate__headShake d-none">
         
         <div class="col-md-12 col-lg-12 col-12 ">
           <!-- The time line -->
           <div class="card">
                      <div class="card-header">
                        <div class="card-title">
                          History Logs
                        </div>
                         
                       </div>
                      <div class="card-body">
                        <div id="logstimeline" class="timeline overflow-auto h-100">
                           <?php include 'server_logs.php'; ?>                  
                         </div>
                     </div>
                  
               
           </div>
            
         </div>
           
           
   </div>
   <!-- /.col -->
