<div id="message" class="row animate__animated animate__headShake d-none">
         
         <div class="col-md-12 col-lg-12 col-12 ">
           <!-- The time line -->
           <div class="card">
                      <div class="card-header">
                         

                             <div class="card-tools">
                             <button id="submitMsg" class="btn"><i class="far fa-envelope"></i> Compose Message</button>
                             </div>
                       </div>
                      <div class="card-body">
                        <div id="msgtimeline" class="timeline overflow-auto h-100">
                           <?php include 'showmessage.php'; ?>                  
                         </div>
                     </div>
                  
               
           </div>
            
         </div>
           
           
   </div>
   <!-- /.col -->
